import wikipedia
query=wikipedia.page("Virat Kohli")
print(query.summary)