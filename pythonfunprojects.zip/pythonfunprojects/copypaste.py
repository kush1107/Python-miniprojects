import pyperclip
pyperclip.copy("Hello World")
pyperclip.paste()