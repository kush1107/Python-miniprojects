from PyDictionary import PyDictionary
dictionary=PyDictionary()

print(dictionary.meaning("intelligence"))