from auto_corrector import correct
sentence="this is pythln"
res=correct(sentence)
print(res)